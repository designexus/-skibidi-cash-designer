
# Skibidi Cash Design Guidelines

## Colors
- Cream: `#FFF8E7`
- Warm Yellow: `#FFD54F`
- Bold Orange: `#FF6F00`
- Electric Purple: `#9C27B0`
- Dark Gray: `#333333`

## Fonts
- Headings: Poppins / Montserrat
- Body: Inter / Roboto

## UI Elements
- Rounded corners: `rounded-2xl`
- Shadows: `shadow-lg`
- Buttons: Hover transitions, `hover:scale-105`, `hover:shadow-xl`

## Components
- Cards with iconography
- Scroll animations via Framer Motion / AOS
